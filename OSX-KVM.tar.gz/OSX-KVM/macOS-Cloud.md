Add notes from Constantin Jacob.

Note: This pretty much violates everything hardware-wise in the macOS EULA that
one could violate.
